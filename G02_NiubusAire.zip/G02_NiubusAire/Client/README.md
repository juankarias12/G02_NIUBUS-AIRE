# Proyecto Niubus-Aire
Proyecto sobre Aereolinea Comercial realizada en REACT.

## Colaboradores Proyecto (100% - Participativos )
 Jenifer Karina Alfonso- 2215109||
 Juan Carlos Arias González- 2225007||
 Juan Diego Herrera Cáceres- 2151316||
 Johany Moreno Moreno- 2215512 ||

## Instrucciones para Correcta Ejecución

Modulos/librerias a descargar para el funcionamiento del proyecto. 

### `Instalar modulos de REACT`
#### npm install react react-dom 
### `Instalar react-bootstrap`
#### npm install react-bootstrap bootstrap
### `Ejecutar Proyecto`
#### npm start

## Login
### `Credenciales`
#### user : 'usuario'
#### password : 'contraseña'
### `Nota`
#### La pestaña Reservas es de tipo privada, por lo que necesita del login para tener acceso a la misma. 
